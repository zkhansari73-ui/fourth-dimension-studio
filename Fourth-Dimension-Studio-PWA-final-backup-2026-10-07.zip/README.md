# Fourth Dimension Studio — PWA final backup

Backup date: 2026-10-07

Live site: https://fourth-dimension-studio.infinityfreeapp.com/

## Final changes

- The primary URL now forwards to the known install experience through `app-main-v9.js`.
- Install target: `/?fd=pwa-clean-10#install-app`
- SuperPWA app and splash icons use the new transparent gold 3D logo.
- Service worker version was advanced to `2.2.48.5`.
- W3 Total Cache was purged after the changes.

## Live asset locations

- Main script: `/wp-content/themes/fourth-dimension-theme/site/app-main-v9.js`
- Manifest: `/superpwa-manifest.json`
- Service worker: `/superpwa-sw.js`
- 192 icon: `/wp-content/uploads/2026/10/app-icon-192-transparent.png`
- 512 icon: `/wp-content/uploads/2026/10/app-icon-512-transparent.png`

## Restore instructions

1. Upload `source-logo-3d.png` and generate transparent 192×192 and 512×512 PNG icons.
2. Point all SuperPWA icon fields to those two PNG files.
3. Keep `scope` and `start_url` at the site root.
4. Add the code from `root-install-redirect.js` to the beginning of `site/app-main-v9.js`.
5. Increase the service-worker version and purge all caches.

