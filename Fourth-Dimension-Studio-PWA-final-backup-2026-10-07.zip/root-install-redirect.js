(()=>{
  const url = new URL(location.href);
  if (url.pathname === '/' && !url.searchParams.has('fd')) {
    location.replace('/?fd=pwa-clean-10#install-app');
  }
})();

